from pymongo import MongoClient
from bson.objectid import ObjectId

data = dict()


class animalCollection(object):
    def __init__(self, username, password, host, port):
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/AAC')
        self.database = self.client['AAC']
        print("Connected to Database")

    def create(self, data):
        try:
            if data is not None:
                insert_result = self.database.animals.insert_one(data)
                print(insert_result)
                return True
            else:
                raise Exception("Nothing to save, data is empty")
        except:
            return False

    def read(self, readData):
        try:
            if readData is not None:
                read_result = self.database.animals.insert_one(data)
                return read_result
            else:
                raise Exception("Nothing to find. Target is empty.")
                return False
        except Exception as e:
            print("Exception has occured: ", e)

    def update(self, query, new_data, count):
        if query is not None:
            if count == 1:
                update_result = self.database.animals.update(query, new_data)
                print("Success!")
                print(update_result)
                return True
            elif count == 2:
                update_result = self.database.animals.update(query, new_data)

                print("Success!")
                print(update_result)
                return True
            else:
                print("Count not recognized - try again.")
                return False
        else:
            raise Exception("Nothing to update, because at least one of the target parameters is empty")
            return False

    def delete(self, deleted_data):
        if target is not None:
            if count == 1:
                try:
                    delete_result = self.database.animals.delete_one(deleted_data)
                    print("Success!")
                    print(delete_result)
                    return True
                except Exception as e:
                    print("An exception has occurred: ", e)
            elif count == 2:
                try:
                    delete_result = self.database.animals.delete_many(deleted_data)
                    print("Success!")
                    print(delete_result)
                    return True
                except Exception as e:
                    print("An exception has occurred: ", e)
                    return False
            else:
                print("Count not recognized - try again.")
                return False
        else:
            raise Exception("Nothing to delete, because the target parameter is empty")
            return False